# Portal Restauradores de la Memoria · IBTI

Institución: **IBTI**. Sede: **Instituto Técnico Central La Salle** (Calle 13 n.º 16-74, Bogotá).

Cambios frente a la versión de Tom Adams IED:
- Identidad, textos, colores (azul lasallista + dorado) y museo 3D adaptados a IBTI / ITC La Salle.
- Nueva sección "Nuestra casa" con línea de tiempo (1893 a 2006) de la sede.
- Se retiraron enlaces, videos, premios y eventos propios de Tom Adams IED; quedan marcadores "por completar".

Pendiente: historia y datos oficiales de IBTI, enlaces/videos reales, modelos 3D propios, y verificar fechas con el archivo institucional.
Para abrirlo: abre index.html en el navegador.

## Museo 3D (museo.html)
Sala con 7 cuadros clicables (carpeta `images/`, archivos `sala-01-…jpg` a `sala-07-…jpg`). Son ilustraciones de referencia: reemplázalas por fotos autorizadas de IBTI / ITC La Salle con el mismo nombre. Títulos y descripciones se editan en `data-title` / `data-desc`.
