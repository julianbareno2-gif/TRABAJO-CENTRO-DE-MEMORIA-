-- Base de datos inicial para MySQL 8+
CREATE DATABASE IF NOT EXISTS ibti_restauradores_memoria
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ibti_restauradores_memoria;

CREATE TABLE Visitantes (
  id_visitante INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  correo VARCHAR(120),
  fecha_visita DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  institucion VARCHAR(120)
);

CREATE TABLE Eventos (
  id_evento INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT,
  fecha_inicio DATE,
  fecha_fin DATE,
  lugar VARCHAR(150),
  estado VARCHAR(30) DEFAULT 'planeado'
);

CREATE TABLE Actividades (
  id_actividad INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT,
  fecha DATE,
  responsable VARCHAR(100),
  id_evento INT NULL,
  FOREIGN KEY (id_evento) REFERENCES Eventos(id_evento) ON DELETE SET NULL
);

CREATE TABLE Objetos_Museo (
  id_objeto INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT,
  url_modelo_3d VARCHAR(500),
  url_fotografia VARCHAR(500),
  autor_equipo VARCHAR(120),
  creditos TEXT,
  fecha_creacion DATE
);

CREATE TABLE Exposiciones (
  id_exposicion INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT,
  fecha_inicio DATE,
  fecha_fin DATE,
  ubicacion VARCHAR(150)
);

CREATE TABLE Evidencias (
  id_evidencia INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(150) NOT NULL,
  tipo VARCHAR(40),
  url VARCHAR(500),
  fecha DATE,
  descripcion TEXT,
  id_evento INT NULL,
  id_exposicion INT NULL,
  FOREIGN KEY (id_evento) REFERENCES Eventos(id_evento) ON DELETE SET NULL,
  FOREIGN KEY (id_exposicion) REFERENCES Exposiciones(id_exposicion) ON DELETE SET NULL
);

CREATE TABLE Aliados (
  id_aliado INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  tipo VARCHAR(80),
  sitio_web VARCHAR(500),
  contacto_institucional VARCHAR(150),
  descripcion TEXT
);

CREATE TABLE Reconocimientos (
  id_reconocimiento INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(180) NOT NULL,
  entidad VARCHAR(150),
  fecha DATE,
  descripcion TEXT,
  url_evidencia VARCHAR(500)
);

-- Datos iniciales (marcadores de posición). Las fechas se confirman con IBTI.
INSERT INTO Eventos (nombre, descripcion, lugar, estado) VALUES
('Inauguración del Museo Escolar de la Memoria', 'Presentación de la primera sala virtual a la comunidad de IBTI.', 'Instituto Técnico Central La Salle, Calle 13 n.º 16-74, Bogotá', 'planeado'),
('Voces de los talleres', 'Entrevistas a egresados y docentes sobre los oficios y la vida en el instituto.', 'Instituto Técnico Central La Salle', 'planeado');

INSERT INTO Reconocimientos (nombre, entidad, descripcion, url_evidencia) VALUES
('Primer puesto entre colegios públicos de Bogotá (2023)', 'Instituto Técnico Central (referencia histórica de la sede)', 'Dato tomado de reportaje de Las2orillas; verificar con fuente oficial.', 'https://www.las2orillas.co/la-formula-del-instituto-tecnico-central-convertirse-en-el-mejor-colegio-publico-de-bogota/');
